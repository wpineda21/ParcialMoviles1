package com.naldana.loginapp

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    var user: String = ""
    var password: String = ""
}