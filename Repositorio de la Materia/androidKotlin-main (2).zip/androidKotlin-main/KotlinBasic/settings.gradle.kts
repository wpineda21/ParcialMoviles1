
rootProject.name = "KotlinBasic"

