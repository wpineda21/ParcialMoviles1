package clases

data class Notas(var nota1: Int, var nota2: Int){
    var comment: String = ""
}
