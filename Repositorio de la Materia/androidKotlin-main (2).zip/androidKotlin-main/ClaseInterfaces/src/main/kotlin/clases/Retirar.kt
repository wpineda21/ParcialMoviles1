package clases

interface Retirar {
    fun retirar(codeMateria: String, pago: Int) : Boolean
}