package clases

object SuperRetirar: Retirar{
    override fun retirar(codeMateria: String, pago: Int): Boolean {
        TODO("Not yet implemented")
    }
}