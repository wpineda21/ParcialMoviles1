package clases

abstract class Ciclo {
    abstract fun asignarEvaluacion()
}