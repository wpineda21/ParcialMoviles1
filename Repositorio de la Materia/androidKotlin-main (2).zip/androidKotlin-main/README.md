# Programación de dispositivos Moviles

En este repositorio podras encontrar ejemplos que te seran utiles para comprender como desarrollar apliaciones para dispositivos Android con Kotlin.

Normalmente las personas que inician en android tienen alguna experiencia en algun otro lenguaje de programación como Java, C#, C++ ... Para que estos ejemplos sean utilies es necesario tener conocimiento básico de programación orientada a objetos en cualquier lenguaje

# Contenido

- Kotlin Basics
	1. Sintaxis Básica en Kotlin.
	2. Funciones en Kotlin.
