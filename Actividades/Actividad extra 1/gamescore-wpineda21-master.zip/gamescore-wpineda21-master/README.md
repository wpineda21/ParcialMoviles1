# TODO

- Añadir la funcionalidad de +2 y +3.

## Tomar en cuenta

- Evitar la repitición de código
