package com.naldana.pokedex.data.entity

data class NamedAPIResource(
    var name: String,
    var url: String
)