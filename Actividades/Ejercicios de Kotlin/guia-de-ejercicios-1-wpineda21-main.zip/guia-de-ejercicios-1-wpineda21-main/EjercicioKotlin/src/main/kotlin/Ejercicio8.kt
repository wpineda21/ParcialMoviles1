
fun main(args:Array<String>) {
    Nombres();
}

fun Nombres() {

    val Paises = mutableListOf(" ") // Lista que no puede cambiar sus valores depues de creada

    println("Ingrese el numero de Paisese que usted Quiere ingresar al arreglo:")
    var b = readLine()!!.toInt()
    var a = ""

    for (i in 1..b) {
        println("Ingrese un Pais:")
        a = readLine().toString();
        Paises.add(a)
    }

    for ((i, NombrePais) in Paises.withIndex()) {
        println("Soy de: $NombrePais")
    }
}