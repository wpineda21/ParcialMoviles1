
fun main(args:Array<String>) {
    var numero=0;

    println("Ingrese el Numero al cual desea calcular su factorial :")
    numero=readLine()!!.toInt()
    println("El Factorial de $numero es: ")
    println(Recursivo(numero))
    println()
}

fun Recursivo(numero: Int): Int {
    if (numero <= 1)
        return 1;
    return numero * Recursivo(numero - 1);
}


