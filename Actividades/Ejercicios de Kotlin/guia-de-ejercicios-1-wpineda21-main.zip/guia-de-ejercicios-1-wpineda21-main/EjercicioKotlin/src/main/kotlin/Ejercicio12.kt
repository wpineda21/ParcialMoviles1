fun main(args:Array<String>) {
    var P1=0
    var P2=0
    var P3=0
    var A1=0
    var A2=0

    println("Hola Carlitos Por favor Ingresa La nota Que se te Solicita:")
    println("Ingresa la nota del Parcial 1:")
    P1= readLine()!!.toInt()
    println("Ingresa la nota del Parcial 2:")
    P2= readLine()!!.toInt()
    println("Ingresa la nota del Parcial 3:")
    P3= readLine()!!.toInt()
    println("Ingresa la nota de la Actividad 1:")
    A1= readLine()!!.toInt()
    println("Ingresa la nota de la Actividad 2:")
    A2= readLine()!!.toInt()

    val P2y3 = intArrayOf(P2,P3)
    val A1y2 = intArrayOf(A1,A2)

    println(CarlitosMaterias(P1,P2y3,A1y2))

}

fun CarlitosMaterias(P1: Int, P2y3: IntArray, A1y2: IntArray) {
    var aux=0.0;
    var auxi2=0.0;
    var auxi3=0.0;
    var Nota=0.0

    aux=(P2y3[0]*0.25)+(P2y3[1]*0.25)
    auxi2=(A1y2[0]*0.15)+(A1y2[1]*0.15)
    auxi3=(P1*0.20);

    Nota=(aux+auxi2 +auxi3)

    if (Nota >= 6){
        println("Felicidades Paso la Materia con: $Nota")
    }else{
        println("Nimodo en Segunda se Pasa: $Nota")
    }

}



