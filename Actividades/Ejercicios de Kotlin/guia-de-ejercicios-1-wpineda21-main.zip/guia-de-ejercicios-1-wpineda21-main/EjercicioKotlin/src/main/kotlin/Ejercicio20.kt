import java.util.*
import kotlin.collections.LinkedHashSet
import java.util.Arrays

fun main(args: Array<String>) {

    val ar = intArrayOf(5, 5, 5,1, 1, 3, 5, 1, 2)
    Arrays.sort(ar)
    var contador = 0
    var aux = ar[0]
    for (i in ar.indices) {
        if (aux == ar[i]) {
            contador++
        } else {
            println(" Este ${ar[i]} aparece $contador  veces")
            contador = 1
            aux = ar[i]
        }
    }
    print(contador)

}