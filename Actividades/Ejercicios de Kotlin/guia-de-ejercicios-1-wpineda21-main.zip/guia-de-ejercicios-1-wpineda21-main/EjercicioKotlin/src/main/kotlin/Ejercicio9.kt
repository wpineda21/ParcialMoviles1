fun main(args:Array<String>) {
    var a=0;
    var b=0;
    var respuesta="";

    println("Ingrese los Dos numeros a Sumar")
    print("numero 1: ")
    a=readLine()!!.toInt()
    print("numero 2: ")
    b=readLine()!!.toInt()


    var option =0;

    do {
        println("Bienvenido a tu calculadora Cientifica Selecciones una Opcion: ")
        println("1)Suma de Numeros...................")
        println("2)resta de Numeros..................")
        println("3)Multiplicacion de Numeros.........")
        println("4)Division de Numeros...............")
        println("5)Salir.............................")
        println("Seleccione una Opcion")
        option= readLine()!!.toInt()
    }while (option !in 1..5)


    if (option==1){
        respuesta = a.plus(b).toString()
        println("la suma es:")
        print(respuesta)
    }else if (option==2){
        respuesta = a.minus(b).toString()
        println("la resta es:")
        print(respuesta)
    }else if (option==3){
        respuesta = (a*b).toString();
        println("la Multiplicacion es:")
        print(respuesta)
    }else if (option==4){
        respuesta = a.div(b).toString()
        println("la division es:")
        print(respuesta)
    }

}