fun main(args: Array<String>) {
    val listNum = arrayListOf<Int>()
    var cant: Int
    var valor: Int

    print("¿Cuantos valores desea ingresar?: ")
    cant = readLine()!!.toInt()
    for(v in 1..cant) {
        print("Ingrese el valor $v: ")
        valor = readLine()!!.toInt()
        listNum.add(valor)
    }

    var NumerosImpares = listNum.filter{ it % 2 != 0 }.toTypedArray()
    var NumerosPares = listNum.filter{ it % 2 == 0 }.toTypedArray()

    var suma=0;
    var mult=0

    if (NumerosImpares!=null){
        for (i in 0..NumerosImpares.size-1){
            suma += NumerosImpares[i]
        }
    }
    if(NumerosPares!=null){
        for (i in 0..NumerosPares.size-1){
            println(i)
           // mult = NumerosPares[i] * NumerosPares[i-1]
        }
    }

    println("La Suma de los Numeros impares es $suma");
    println("La Multiplicacion de los Numeros pares es $mult");

}

