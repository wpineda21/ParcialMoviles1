
fun main(args: Array<String>) {
    var a=0
    var b=0
    var myList = mutableListOf("0")

    println()
    println("Escriba el numero de elementos que desea contener en la lista.")
    b = readLine()!!.toInt();
    println("Escriba las veces que quiere rotar la Lista")
    a = readLine()!!.toInt();


    for (b in 0..b-1){
        println("Escriba un elemento de la lista:  ")
        var c= readLine()!!.toInt()
        myList.add(c.toString())
    }

    println("Lista Original")
    println(myList)
    println("lista Rotada")
    RotarElementos(myList,a,b)
    println(myList)
}


fun RotarElementos(myList: MutableList<String>, a: Int, b: Int) {

    for (a in 1..a) {

        val aux = myList.get(0)
        myList.add(myList.size, aux.toString())
        myList.removeAt(0)

    }
}