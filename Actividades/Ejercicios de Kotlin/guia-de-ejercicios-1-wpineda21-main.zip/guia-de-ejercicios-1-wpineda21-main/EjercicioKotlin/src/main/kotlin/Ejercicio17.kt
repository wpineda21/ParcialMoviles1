


fun main(args:Array<String>) {

    var boleano = false;

    do{
        println("Ingrese un Numero con Dos o mas Digitos Mi Amigo:")
        val n: Int = readLine()!!.toInt()
        if(n>0){
            SumarNumeros(n)
            boleano=true;
        }else{
            println("Ingrese un Numero Positivo")
        }
    }while (!boleano)


}

fun SumarNumeros(n: Int) {
    val d = Integer.toString(n).length
    var t = 0
    if (d >= 2) {
        for (i in 0 until d) {
            val num = Integer.toString(n)[i].toString()
            t += num.toInt()
        }
    } else {
        println("Tiene Que Tener dos o mas Digitos")
    }
    println("El resultado es: $t")
}