fun main(args:Array<String>) {

    val Animales = mutableListOf(" ")
    var DatosLista="";
    var PalabraAbuscar="";

    println("Cuantos Animales Quiere Que Tenga la Lista")
    var option = readLine()!!.toInt()

    for (i in 0 until option){
        println("Ingrese Los Datos de la Lista")
        DatosLista= readLine().toString().toUpperCase()
    }
    Animales.add(DatosLista);

    println("Que Parametro Desea Buscar?")
    PalabraAbuscar = readLine().toString().toUpperCase();

    buscarXD(PalabraAbuscar,Animales)
}

fun buscarXD(PalabraAbuscar: String, Animales: MutableList<String>) {

    val ListaAnimales = mutableListOf(" ")
    var DatoBooleano=false;

    for (i in Animales){
        if (i.contains(PalabraAbuscar)){
            println("Palabras Encontranda $i")
            ListaAnimales.add(i)
            DatoBooleano=true;
        }
    }
    if (DatoBooleano==true){
        println("Los Animales Encontrados Son:  $ListaAnimales" )
    }else{
        println("No Se Encontro Ninduna coincidencia ")
    }



}