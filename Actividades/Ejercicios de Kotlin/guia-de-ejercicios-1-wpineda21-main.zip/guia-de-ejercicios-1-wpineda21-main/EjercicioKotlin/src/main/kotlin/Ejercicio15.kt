
// INICIO
fun main(args: Array<String>) {

    val secreta = PedirPalabra()
    val oculta = Array(secreta.length) { "_" }
    oculta.forEach { print("$it ") }
    println()
    val letrasUsadas: MutableList<String> = mutableListOf()
    var Vidas = 0
    var acierto = 0
    do {
        val letra = PedirLetras()
        if (letrasUsadas.contains(letra)) {
            println("La letra $letra ya la has dicho.")
            print("Letras usadas: ")
            letrasUsadas.forEach { print("$it ") }
            println()
            oculta.forEach { print("$it ") }
            println()
        } else {
            letrasUsadas.add(letra)

            if (letra in secreta) {
                acierto++
                for (index in secreta.indices) {
                    if (letra == secreta[index].toString()) oculta[index] = letra
                }
                oculta.forEach { print("$it ") }
                println()
                if (secreta == oculta.joinToString(separator = "")) {
                    println("GG IZI Felicidad adivinaste")
                    break
                }
            } else { // ERROR
                Vidas++
                println("No es esa :( $Vidas")
                if (Vidas == 3) println("Lo siento amigo pero La Palabra era :  $secreta")
            }
        }
    } while (Vidas < 3)
}

fun PedirPalabra(): String {
    println("Introduce la palabra secreta: ")
    val palabra = readLine().toString().toUpperCase()
    println("La Primera letra de laPalabra es: ")
    println(palabra[0])
    println("La UltimaL letra de la Palabra es: ")
    println(palabra.substring(palabra.length-1))
    println("La Palabra Contiene: ${palabra.length} letras")
    return palabra;
}

fun PedirLetras(): String {
    val LETRAS = ('A'..'Z') + 'Ñ'
    do {
        print("Una letra: ")
        val letra = readLine().toString().toUpperCase()
        if (letra.length != 1 || letra.single() !in LETRAS) {
            println("Letra no reconocida. Inténtalo otra vez.")
        } else {
            return letra
        }
    } while (true)
}
