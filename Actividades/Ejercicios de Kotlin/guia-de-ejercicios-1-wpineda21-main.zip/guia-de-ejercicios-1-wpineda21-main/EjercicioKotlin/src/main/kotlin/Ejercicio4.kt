
fun main(args:Array<String>) {
    println( PigLatin("the quick brown fox"))
}

fun PigLatin(translate :String): String{
    var translated=""

    translate.split(' ').toMutableList().forEach(){
        translated += it.substring(1)+it.first()+"ay"
    }

  return  translated
}