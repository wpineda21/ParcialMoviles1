fun main(Args: Array<String>) {
    var (igual, aux) = Pair(0, 0)
    var texto : String

    print("Ingrese una palabra: ")
    texto = readLine() as String
    for (ind in texto.length - 1 downTo 0) {
        when { texto[ind] == texto[aux] -> igual++ }
        aux++
        println(ind)
    }

    when (igual) {
        texto.length -> println("$texto es palindromo!!")
        else -> println("$texto no es palindromo!!")
    }

}