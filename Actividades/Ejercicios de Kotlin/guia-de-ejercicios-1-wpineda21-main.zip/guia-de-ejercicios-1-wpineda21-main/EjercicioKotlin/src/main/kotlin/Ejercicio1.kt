fun main(args:Array<String>) {

    println("Palabra a evaluar: ")
    var word = readLine()!!.toString();
    println("Cantidad de letras que se van a ingresar:")
    var cant = readLine()!!.toInt();
    var myList: MutableList<Char> = mutableListOf()

    for (i in 1..cant){
        println("Ingrese la letra #${i}:  ")
        var letra: Char = readLine()!![0]
        myList.add(letra)
    }
    palachar(word,myList)
}

fun palachar(word: String, charlist: MutableList<Char>) {

    var palabra = word.toCharArray()

    for (i in 0 until charlist.size){
        for (j in 0.. palabra.size ){
            if(palabra[j] == charlist[i]){
                println("La letra ${charlist[i]} aparece en la posicion ${j} de la palabra ${word}")
                break;
            }
        }
    }
}