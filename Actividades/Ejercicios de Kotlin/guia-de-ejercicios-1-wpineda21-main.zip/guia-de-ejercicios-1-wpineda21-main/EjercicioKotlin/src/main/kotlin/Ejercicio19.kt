fun main(args:Array<String>) {

        println("Ingresa La Cantidad de Palabras de la Lista")
        var cantidad = readLine()!!.toInt();
        var aux=0;


        for (i  in 0..cantidad)
        {
            println("Ingrese Las palabras Que Quiere Dar Vuelta")
            var texto = readLine().toString();
            ProcesarYVolcar(texto, i)
        }
}


fun ProcesarYVolcar(texto: String, contador: Int) {

     var palabras = charArrayOf()
        palabras=texto.toCharArray();
        println("Case #{0}:  $contador");
        for (ind in texto.length - 1 downTo 0)
        {
            println(texto[ind-1] );
            if (ind>1)
                println(" ");
        }

        println();
    }
