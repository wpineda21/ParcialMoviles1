fun main(Args: Array<String>) {
    val listNum = arrayListOf<Int>()
    var cant: Int
    var tmp = 0
    var valor: Int
    print("¿Cuantos valores desea ingresar?: ")
    cant = readLine()!!.toInt()
    for(v in 1..cant) {
        print("Ingrese el valor $v: ")
        valor = readLine()!!.toInt()
        listNum.add(valor)
    }
    for(x in 0 until cant) {
        for(y in 0 until cant) {
            if(listNum[x] < listNum[y]) {
                tmp = listNum[y]
                listNum[y] = listNum[x]
                listNum[x] = tmp
            }
        }
    }
    println("\nNumeros ordenados: $listNum")
}