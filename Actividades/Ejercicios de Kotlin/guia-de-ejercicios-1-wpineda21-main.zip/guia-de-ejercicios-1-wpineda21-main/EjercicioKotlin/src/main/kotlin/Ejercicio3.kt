

fun main(args:Array<String>) {
    println(CuadradosPerfectos())
}

fun CuadradosPerfectos() {
    val array2 = Array(11) { index ->
        index * index
    }
    println("Los Primeros 10 cuadrados perfectos Son:  ")
    println(java.util.Arrays.toString(array2))
}