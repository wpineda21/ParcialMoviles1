fun main(args:Array<String>) {
    var num : Int

    print("Ingrese el numero: ")
    num = readLine()!!.toInt()

    if (num % 2 == 0)
        print("El numero $num es Par")
    else println("El numero $num es Impar")
}


