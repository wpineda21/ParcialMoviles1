import java.lang.StringBuilder

fun main(args:Array<String>) {
    Invertir()
}
fun Invertir(){
    println("Ingrese la Palabra que desee invertir")
    var cadena = readLine()
    val stringBuilder = StringBuilder(cadena)
    val invertida = stringBuilder.reverse().toString()
    println("Palabra original: $cadena")
    println("Palabra invertida: $invertida")
}