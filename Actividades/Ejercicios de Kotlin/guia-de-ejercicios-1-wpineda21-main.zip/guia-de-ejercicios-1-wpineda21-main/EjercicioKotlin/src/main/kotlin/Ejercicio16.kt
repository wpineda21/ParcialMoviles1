import java.util.*
import kotlin.collections.LinkedHashSet

fun main(args: Array<String>) {

    var option=0;
    var DatosdeLista1=0;
    var DatosdeLista2=0;
    val listOne = ArrayList(Arrays.asList(0))
    val listTwo = ArrayList(Arrays.asList(0))


    println("Cuantos Valores Quiere Que Tenga Cada Lista")
        option= readLine()!!.toInt()

    for (i in 0 until option){
        println("Ingrese Los Datos de la PRIMERA Lista")
        DatosdeLista1= readLine()!!.toInt()
        listOne.add(DatosdeLista1);
    }
    println()
    for (i in 0 until option){
        println("Ingrese Los Datos de la SEGUNDA Lista")
        DatosdeLista2= readLine()!!.toInt()
        listOne.add(DatosdeLista2);
    }

    RecibirListas(listOne,listTwo)

}


fun RecibirListas(listOne: ArrayList<Int>, listTwo: ArrayList<Int>) {
    val set: LinkedHashSet<Int> = LinkedHashSet(listOne)
    set.addAll(listTwo)
    val combinedList: ArrayList<Int> = ArrayList(set)
    println("Lista Combinada $combinedList")

}