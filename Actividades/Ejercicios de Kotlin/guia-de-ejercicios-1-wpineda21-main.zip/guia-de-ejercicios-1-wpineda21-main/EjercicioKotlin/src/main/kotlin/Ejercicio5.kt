
fun main(args:Array<String>) {
    fibonacci();
}

fun fibonacci(){
    var a = 0
    var b = 1

    println("Los Primeros 10 terminos de Fibonacci: ")

    for (i in 1..10) {
        println("termino $i = $a")

        val sum = a + b
        a = b
        b = sum
    }
}

