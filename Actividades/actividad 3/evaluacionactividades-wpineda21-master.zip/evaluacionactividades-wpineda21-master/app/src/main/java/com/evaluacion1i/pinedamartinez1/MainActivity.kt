package com.evaluacion1i.pinedamartinez1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    var numeroPrimo: EditText? = null
    var Calcular1: Button? = null
    var Answer: TextView? = null
    var Showdialog: AlertDialog.Builder? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        numeroPrimo = findViewById(R.id.edNumero) as EditText
        Calcular1 = findViewById(R.id.bCalcular) as Button
        Answer = findViewById(R.id.tRespuesta) as TextView

        Calcular1!!.setOnClickListener {
            if (Calcular1!!.text.toString() == "Limpiar") {
                numeroPrimo!!.setText("")
                numeroPrimo!!.isEnabled = true
                numeroPrimo!!.requestFocus()
                Answer!!.text = ""
                Calcular1!!.text = "Calcular"
            } else {
                if (numeroPrimo!!.text.length == 0) {
                    //dialog = Builder(this@MainActivity)
                    Showdialog!!.setTitle("Error")
                    Showdialog!!.setMessage("Ingresar el número")
                    Showdialog!!.setCancelable(false)
                    Showdialog!!.setPositiveButton(
                        "Cerrar"
                    ) { dialogo, id ->
                        dialogo.cancel()
                        numeroPrimo!!.requestFocus()
                    }
                    Showdialog!!.show()
                } else {
                    val numero = numeroPrimo!!.text.toString().toInt()
                    var flat = false
                    for (i in 2 until numero) {
                        if (numero % i == 0) {
                            flat = true
                        }
                    }
                    if (flat) {
                        Answer!!.text = "El número $numero no es primo"
                    } else {
                        Answer!!.text = "El número $numero es primo"
                    }
                    Calcular1!!.text = "Limpiar"
                    numeroPrimo!!.isEnabled = false
                }
            }
        }
    }
}


private fun AlertDialog.Builder.onClick() {
    TODO("Not yet implemented")
}
